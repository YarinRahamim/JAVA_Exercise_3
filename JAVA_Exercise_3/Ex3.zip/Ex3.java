public class Ex3 {		
	//Name: Yarin Rahamim 
	//ID: 205833668 

	//MyID function
	public static String myID() {
		return "205833668";
	}

	//1: Recursive function- enter string and char and move all char in the string to the end.
	public static String moveCharToLast(String str, char ch) {
		if(str.length()<2) {
			return str;
		}
		if(str.charAt(0) == ch) {
			return moveCharToLast(str.substring(1),ch) + str.charAt(0);
		}	
		else {
			return str.charAt(0) + moveCharToLast(str.substring(1),ch);

		}
	}

	//2: Recursive function- enter string and the function reduce the string, for example('aaaab' return 'ab').
	public static String reduce(String str) {
		if(str.length()<2) {
			return str;
		}
		if(str.charAt(0) == str.charAt(1)) {
			return reduce(str.substring(1));
		}
		else {
			return str.charAt(0) + reduce(str.substring(1));
		}
	}


	//3: mySplit function- gets 3 groups of array (A-multiples of 5, B- multiples of 3, C-other numbers),and return true if the sum is equal.
	// Boolean function- return true or false.
	public static boolean mySplit(int[] nums) {
		int groupA[] = new int[nums.length];  // Multiples of 5.
		int groupB[] = new int[nums.length];  // Multiples of 3.
		int groupC[] = new int[nums.length];  // The other numbers.
		int a = 0;
		int b = 0;
		int c = 0;
		for(int i=0 ; i<nums.length ; i++) { // Check the numbers in array.
			if(nums[i]%5 == 0) {		     // If number is multiples of 5
				groupA[a] = nums[i];		 // Enter the number to group A.	
				a++;
			}
			else {
				if(nums[i]%3 == 0) {		// Enter the number is multiples of 3
					groupB[b] = nums[i];	// Put the number to group B.
					b++;
				}
				else {
					groupC[c] = nums[i];	// Else the other numbers enter to group C.
					c++;
				}
			}
		}
		// Send all array A(group A), B(group B),  to auxiliary function, fix the array and return new fix array.
		int arrA[] = fixArr(groupA,a);		
		int arrB[] = fixArr(groupB,b);
		int arrC[] = fixArr(groupC,c);
		return MySplit(arrA,arrB,arrC);
	}

	// Auxiliary recursive function- check if its possible to divide the numbers in array to 2 groups.
	// Boolean function- return true or false.
	private static boolean MySplit(int arrA[], int arrB[], int arrC[]) {
		if(arrC.length<1) {
			return sum(arrA) == sum(arrB);
		}
		int num = arrC[arrC.length-1];
		int newC[] = fixArr(arrC,arrC.length-1);
		int newA[] = add(arrA,num);
		int newB[] = add(arrB,num);
		return MySplit(newA,arrB,newC) || MySplit(arrA,newB,newC);
	}

	// Auxiliary function- fix array and return new array with correct length.
	private static int[] fixArr(int[] arr, int len) {
		int ans[] = new int[len];
		for(int i=0 ; i<len ; i++) {
			ans[i] = arr[i];
		}
		return ans;
	}

	// Auxiliary function- calculate sum of array.
	private static int sum(int arr[]) {
		int sum = 0;
		for(int i=0 ; i<arr.length ; i++) {
			sum += arr[i];
		}
		return sum;
	}

	// Auxiliary function- this function add number(int) to array and return new array.
	private static int[] add(int arr[], int x) {
		int ans[] = new int[arr.length+1];
		for(int i=0 ; i<arr.length ; i++) {
			ans[i] = arr[i];
		}
		ans[arr.length] = x;
		return ans;
	}

	//4: This function calculate the sum of number's neighbors.   
	public static int[][] sumOfNeighbours(int[][] mat){
		int sumOfNi[][] = new int[mat.length][mat[0].length];
		for(int i=0 ; i<mat.length ; i++) {
			for(int j=0 ; j<mat[i].length ; j++) {
				sumOfNi[i][j] = sumOfN(mat,i,j); // Send the matrix array to auxiliary function.
			}
		}
		return sumOfNi;
	}
	// Auxiliary function- calculate the sum in limits of matrix and return the sum.
	private static int sumOfN(int matrix[][], int x, int y) {
		int sum = 0;
		for(int i=Math.max(0, x-1) ; i<=Math.min(matrix.length-1, x+1) ; i++) {
			for(int j=Math.max(0, y-1) ; j<=Math.min(matrix[i].length-1, y+1) ; j++) {
				sum += matrix[i][j];
			}
		}
		return sum - matrix[x][y];
	}


	//5: Caesar Cipher- get string (small letters,without space) and key number(responsible for changing the string) for example: "yarin" with key:1 return "zbsjo".  
	// Use in ASCII table.
	public static String caesarCipherText(String str, int key) {
		String s = "";
		for(int i=0 ; i<str.length() ; i++) {
			char c = str.charAt(i);
			if(c != ' ') {						// If c(char) is not a space return s(the string).	
				s += caesarCipherText(c,key);	// Use in auxiliary function and return s(the string).
			}
			else {								// If c(char) is space add to s(to the string).
				s+=c;		
			}
		}
		return s;
	}
	// Auxiliary function - get char and key(number int) and check when the variable bigger or smaller from the last and first a-b letters as ASCII table.
	private static char caesarCipherText(char c, int key) {
		char a = (char)(c+key);	
		if(a>'z') { 			// If a bigger from 'z'(value in ASCII table) subtraction 26. 
			a = (char)(a-26); 
		}
		else if(a<'a') {	 	// If a smaller from 'a'(value in ASCII table) add 26. 
			a = (char)(a+26);
		}
		return a;				// return a.
	}

	//6- Vigenere Cipher- get string and key string(use in a-b letters) for example: a letters is 0, b is 1. the letters in key move the letters in the string(example: "abc" with b(1) --> "bcd"). 
	// Use in ASCII table.
	public static String vigenereCipherText(String str, String key) {
		String code = "";			
		int keyLen = key.length();	// Key length- the key can be a sentence or word.
		int j=0;
		for(int i=0 ; i<str.length() ; i++) {	// Passing to all the string. 
			if(j>=keyLen) {						// If j bigger or equal to key length j=0. 
				j=0;
			}
			int k = charToKey(key.charAt(j++)); // Send the k to auxiliary function and as ASCII table we change the string, and j++.
			char c = str.charAt(i);				
			if(c == ' ') {						// if c is space add to the c.
				code += c;
			}
			else {
				code += caesarCipherText(c,k); // Send to Caeser Cipher function and return the string cipher.  
			}
		}
		return code;							
	}

	//6*- Vigenere Decipher- similar code but the different is in this code we decipher the code. 
	// Use in ASCII table.
	public static String vigenereDecipherText(String str, String key) {
		String code = "";
		int keyLen = key.length();
		int j=0;
		for(int i=0 ; i<str.length() ; i++) {
			if(j>=keyLen) {
				j=0;
			}
			int k = charToKey(key.charAt(j++));
			char c = str.charAt(i);
			if(c == ' ') {
				code += c;
			}
			else {
				code += caesarCipherText(c,-1*k); // We multiple in -1*k and we decipher the code.
			}
		}
		return code;
	}

	// Auxiliary function- check the cipher letters with ASCII table(if char 'a'-97 return 0).
	private static int charToKey(char c) {
		return c-97;
	}

	public static void main(String[] args) {

	}
}
