import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

class Ex3Test {
	// Name: Yarin Rahamim
	// ID: 205833668

	@Test
	void testMoveCharToLast() {
		//***1***
		String in = "hello world, let's go!";
		String out = "heo word, et's go!llll";
		assertTrue(out.equals(Ex3.moveCharToLast(in,'l')));
		in = "&hi&hi&";
		out = "hihi&&&";
		assertTrue(out.equals(Ex3.moveCharToLast(in,'&')));
		//***2***
		String in2 =  "1111222223333&&&&&&&&";
		String out2 = "222223333&&&&&&&&1111";
		assertTrue(out2.equals(Ex3.moveCharToLast(in2,'1')));
		in2 = "&&@@%%yarin&&@@%%";
		out2 = "&&@@%%arin&&@@%%y";
		assertTrue(out2.equals(Ex3.moveCharToLast(in2,'y')));
		//***3***
		String in3 = "11111110 111000 0101";
		String out3 = "0 000 00111111111111";
		assertTrue(out3.equals(Ex3.moveCharToLast(in3,'1')));
		in3 = "y a r i n ";
		out3 = " a r i n y";
		assertTrue(out3.equals(Ex3.moveCharToLast(in3,'y')));
	}

	@Test
	void testReduce() {
		//***1***
		String in1 = "aaabbccccxxxyzz";
		String out1 = "abcxyz";
		assertTrue(out1.equals(Ex3.reduce(in1)));
		in1 = "abcda";
		out1 = in1;
		assertTrue(out1.equals(Ex3.reduce(in1)));
		//***2***
		String in2 = "aaaaabbbbbcccccddddd11111";
		String out2 = "abcd1";
		assertTrue(out2.equals(Ex3.reduce(in2)));
		in2 = "Ex3123yarin123Ex3";
		out2 = in2;
		assertTrue(out2.equals(Ex3.reduce(in2)));
		//***3***
		String in3 = "00001111222233333456789";
		String out3 = "0123456789";
		assertTrue(out3.equals(Ex3.reduce(in3)));
		in3 = "123456789";
		out3 = in3;
		assertTrue(out3.equals(Ex3.reduce(in3)));
	}

	@Test
	void testMySplit() {
		assertEquals(Ex3.mySplit(new int[] {1,1}),true);
		assertEquals(Ex3.mySplit(new int[] {1,1,1}),false);
		assertEquals(Ex3.mySplit(new int[] {2,4,2}),true);
		assertEquals(Ex3.mySplit(new int[] {5,21,8,15,7}),true);
		assertEquals(Ex3.mySplit(new int[] {15,10,5}),false);
		assertEquals(Ex3.mySplit(new int[] {15,8,7}),true);
		assertEquals(Ex3.mySplit(new int[] {0,0,3}),false);
		assertEquals(Ex3.mySplit(new int[] {1,1,1,1}),true);
		assertEquals(Ex3.mySplit(new int[] {0,0,3}),false);
		assertEquals(Ex3.mySplit(new int[] {0}),true);
		assertEquals(Ex3.mySplit(new int[] {0,1,0,1}),true);
	}

	@Test
	void testSumOfNeighbours() {
		//***1***
		int[][] mat1 = {{3,5,7,5},{-4,2,10,11},{9,-50,3,60}};
		int[][] matOut1 = {{3,18,33,28},{-31,-17,43,85},{-52,20,33,24}};
		mat1 = Ex3.sumOfNeighbours(mat1);
		for(int i=0; i < mat1.length ;++i)
			assertTrue(Arrays.equals(mat1[i], matOut1[i]));

		//***2***
		int[][] mat2 = {{1,-2},{4,1}};
		int[][] matOut2 = {{3,6},{0,3}};
		mat2 = Ex3.sumOfNeighbours(mat2);
		for(int i=0; i < mat2.length ;++i)
			assertTrue(Arrays.equals(mat2[i], matOut2[i]));	
		//***3***
		int[][] mat3 = {{1,1,1,1},{1,1,1,1},{1,1,1,1}};
		int[][] matOut3 = {{3,5,5,3},{5,8,8,5},{3,5,5,3}};
		mat3 = Ex3.sumOfNeighbours(mat3);
		for(int i=0; i < mat3.length ;++i)
			assertTrue(Arrays.equals(mat3[i], matOut3[i]));	
		//***4***
		int[][] mat4 = {{1,-2},{4,1}};
		int[][] matOut4 = {{3,6},{0,3}};
		mat4 = Ex3.sumOfNeighbours(mat4);
		for(int i=0; i < mat4.length ;++i)
			assertTrue(Arrays.equals(mat4[i], matOut4[i]));	
		//***5***
		int[][] mat5 = {{0,0,0,0},{0,0,0,0}};
		int[][] matOut5 = {{0,0,0,0},{0,0,0,0}};
		mat5 = Ex3.sumOfNeighbours(mat5);
		for(int i=0; i < mat5.length ;++i)
			assertTrue(Arrays.equals(mat5[i], matOut5[i]));	
	}

	@Test
	void testCaesarCipherText() {
		//***1***
		String in = "abcdefghijklmnopqrstuvwxyz ";
		String out = "efghijklmnopqrstuvwxyzabcd ";
		assertTrue(out.equals(Ex3.caesarCipherText(in, 4)));
		assertTrue(in.equals(Ex3.caesarCipherText(Ex3.caesarCipherText(in, 4),-4)));
		//***2***
		String in2 = "matala number three by yarin rahamim";
		String out2 = "nbubmb ovncfs uisff cz zbsjo sbibnjn";
		assertTrue(out2.equals(Ex3.caesarCipherText(in2, 1)));
		assertTrue(in2.equals(Ex3.caesarCipherText(Ex3.caesarCipherText(in2, 1),-1)));
		//***3***
		String in3 = "my name is yarin rahamim";
		String out3 = "my name is yarin rahamim";
		assertTrue(out3.equals(Ex3.caesarCipherText(in3, 26)));
		assertTrue(in3.equals(Ex3.caesarCipherText(Ex3.caesarCipherText(in3, 26),-26)));
	}

	@Test
	void testVigenereCipherText() {
		//***1***
		String in = "a simple example";
		String out = "a zqqkpq rqaowti";
		assertTrue(out.equals(Ex3.vigenereCipherText(in, "achievement")));
		in = "impressive student from ariel university";
		out = "pacfvzgvjv ggiulbg wycz rywrz bbvjvygvhp";
		assertTrue(out.equals(Ex3.vigenereCipherText(in, "honor")));
		in = "test";
		out = "test";
		assertTrue(out.equals(Ex3.vigenereCipherText(in, "a")));
		//***2***
		String in2 = "my name is yarin rahamim";
		String out2 = "op ecdg kj pcike icycdkd";
		assertTrue(out2.equals(Ex3.vigenereCipherText(in2, "cr")));
		in2 = "i am a student in ariel university";
		out2 = "c ih r amsxrvo zf tpcrt yeadxpmvbt";
		assertTrue(out2.equals(Ex3.vigenereCipherText(in2, "university")));
		in2 = "yarin";
		out2 = "yarin";
		assertTrue(out2.equals(Ex3.vigenereCipherText(in2, "a")));
		//***3***
		String in3 = "matala number three";
		String out3 = "mbvamc owmcgr vhsge";
		assertTrue(out3.equals(Ex3.vigenereCipherText(in3, "abc")));
		in3 = " "; // null string
		out3 = " "; // null string
		assertTrue(out3.equals(Ex3.vigenereCipherText(in3, "abcdefghiklmnop")));
		in3 = "ex three test";
		out3 = "qx tsrqe tpsf";
		assertTrue(out3.equals(Ex3.vigenereCipherText(in3, "matala")));
	}

	@Test
	void testVigenereDecipherText() {
		//***1***
		String in = "c ih r amsxrvo zf tpcrt yeadxpmvbt"; // i am a student in ariel university
		String key = "university";
		assertTrue(in.equals(Ex3.vigenereDecipherText(Ex3.vigenereCipherText(in,key),key)));	
		//***2***
		String in2 = "pacfvzgvjv ggiulbg wycz rywrz bbvjvygvhp"; // impressive student from ariel university
		String key2 = "honor";
		assertTrue(in2.equals(Ex3.vigenereDecipherText(Ex3.vigenereCipherText(in2,key2),key2)));	
		//***3***
		String in3 = "op ecdg kj pcike icycdkd"; // my name is yarin rahamim
		String key3 = "cr";
		assertTrue(in3.equals(Ex3.vigenereDecipherText(Ex3.vigenereCipherText(in3,key3),key3)));	
	}

}
